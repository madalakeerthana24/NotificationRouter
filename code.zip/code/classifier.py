import re

def classify_text(text):

    text = str(text).lower()

    if any(x in text for x in [
        "otp",
        "password",
        "verify",
        "bank",
        "urgent",
        "pay now",
        "electricity",
        "bill"
    ]):

        return {
            "message_type":"payment",
            "urgency":0.95,
            "importance":0.90,
            "risk":0.10,
            "promotion":0.0,
            "reason":"Payment or verification message"
        }

    if any(x in text for x in [
        "sale",
        "offer",
        "discount",
        "buy",
        "coupon"
    ]):

        return {
            "message_type":"promotion",
            "urgency":0.2,
            "importance":0.3,
            "risk":0.1,
            "promotion":0.95,
            "reason":"Marketing content"
        }

    if any(x in text for x in [
        "click here",
        "lottery",
        "won",
        "prize",
        "free money"
    ]):

        return {
            "message_type":"scam",
            "urgency":0.2,
            "importance":0.2,
            "risk":0.98,
            "promotion":0.2,
            "reason":"Possible scam"
        }

    return {
        "message_type":"personal",
        "urgency":0.5,
        "importance":0.5,
        "risk":0.1,
        "promotion":0.0,
        "reason":"General conversation"
    }