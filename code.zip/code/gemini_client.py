import os
import json
from dotenv import load_dotenv
from google import genai

load_dotenv()

client = genai.Client(
    api_key=os.getenv("GEMINI_API_KEY")
)

SYSTEM_PROMPT = """
You are an AI notification assistant.

Return ONLY JSON.

Schema:

{
"message_type":"",
"urgency":0.0,
"importance":0.0,
"risk":0.0,
"promotion":0.0,
"summary":"",
"reason":""
}
"""

def analyze_message(message):

    response = client.models.generate_content(
        model="gemini-2.0-flash",
        contents=f"""
{SYSTEM_PROMPT}

Message:

{message}
"""
    )

    text = response.text.strip()

    if text.startswith("```"):
        text = text.replace("```json", "")
        text = text.replace("```", "")
        text = text.strip()

    return json.loads(text)