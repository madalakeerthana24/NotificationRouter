from loader import load_all_data

data = load_all_data()
images = data["images"]

def process_image(media_id):
    row = images[images["image_id"] == media_id]

    if len(row) == 0:
        return ""

    # Return the file path for now.
    # You can later replace this with OCR.
    return row.iloc[0]["file_path"]