import pandas as pd

output = pd.read_csv("dataset/output.csv")

assert len(output) == 110

required = [
    "message_id",
    "action",
    "message_type",
    "reason",
    "confidence",
    "evidence_message_ids"
]

for c in required:
    assert c in output.columns

assert output["confidence"].between(0,1).all()

print("Evaluation Passed ✅")