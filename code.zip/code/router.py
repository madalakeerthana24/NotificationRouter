from history_engine import get_history_score
from personalization import get_user_score
from business_engine import get_business_score
from group_engine import get_group_priority


def decide_action(message, ai):

    urgency = ai["urgency"]
    importance = ai["importance"]
    risk = ai["risk"]
    promotion = ai["promotion"]

    history = get_history_score(message["user_id"])
    personal = get_user_score(message["user_id"])

    business = get_business_score(
        message["user_id"],
        message["business_id"]
    )

    group = get_group_priority(
        message["user_id"],
        message["group_id"]
    )

    score = (
        urgency * 0.35
        + importance * 0.25
        + history * 0.15
        + personal * 0.10
        + business * 0.10
        + group * 0.05
    )

    if risk > 0.8:
        action = "mute"

    elif promotion > 0.8:
        action = "digest"

    elif score > 0.70:
        action = "notify"

    elif score > 0.40:
        action = "digest"

    else:
        action = "mute"

    return {

        "message_id": message["message_id"],

        "action": action,

        "message_type": ai["message_type"],

        "reason": ai["reason"],

        "confidence": round(score,2),

        "evidence_message_ids":
        history["evidence"]

    }