from loader import load_all_data

data = load_all_data()

groups = data["groups"]
members = data["group_members"]


def get_group_priority(user_id, group_id):

    if group_id is None:
        return 0.5

    row = members[
        (members["user_id"] == user_id) &
        (members["group_id"] == group_id)
    ]

    if len(row) == 0:
        return 0.5

    row = row.iloc[0]

    score = 0.5

    if "is_muted" in row and row["is_muted"] == 1:
        score -= 0.5

    if "role" in row:

        role = str(row["role"]).lower()

        if "admin" in role:
            score += 0.2

    return max(0, min(score, 1))