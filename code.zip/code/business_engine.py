from loader import load_all_data

data = load_all_data()

business = data["business"]
history = data["user_business_history"]


def get_business_score(user_id, business_id):

    if business_id is None:
        return 0.5

    b = business[business["business_id"] == business_id]

    if len(b) == 0:
        return 0.5

    score = 0.5

    row = b.iloc[0]

    if "verified" in row and row["verified"] == 1:
        score += 0.3

    if "reports" in row:
        score -= min(row["reports"] * 0.02, 0.4)

    h = history[
        (history["user_id"] == user_id) &
        (history["business_id"] == business_id)
    ]

    if len(h) > 0:
        score += 0.2

    return max(0, min(score, 1))