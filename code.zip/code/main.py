import pandas as pd

from loader import load_all_data
from classifier import classify_text
from router import decide_action
from image_processor import process_image
from voice_processor import process_voice

# Load all datasets
data = load_all_data()

messages = data["messages"]

results = []

for _, row in messages.iterrows():

    # Start with text message
    message_text = str(row["message_text"]) if pd.notna(row["message_text"]) else ""

    # Handle image messages
    if row["media_type"] == "image":
        image_info = process_image(row["media_id"])
        message_text += " " + image_info

    # Handle voice notes
    elif row["media_type"] == "voice":
        voice_info = process_voice(row["media_id"])
        message_text += " " + voice_info

    # AI classification
    ai = classify_text(message_text)

    # Personalized routing
    result = decide_action(row, ai)

    results.append(result)

# Save output
output = pd.DataFrame(results)

output.to_csv("dataset/output.csv", index=False)

print(output.head())
print("\nDone! output.csv generated successfully.")