from pathlib import Path

# Project Root
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# Dataset
DATASET_DIR = PROJECT_ROOT / "dataset"

# Media
MEDIA_DIR = DATASET_DIR / "media"
IMAGE_DIR = MEDIA_DIR / "images"
AUDIO_DIR = MEDIA_DIR / "audio"

# Output
OUTPUT_DIR = PROJECT_ROOT / "code" / "outputs"
LOG_DIR = PROJECT_ROOT / "code" / "logs"

OUTPUT_FILE = OUTPUT_DIR / "output.csv"
LOG_FILE = LOG_DIR / "log.txt"

# CSV Files
MESSAGES_CSV = DATASET_DIR / "messages.csv"
USERS_CSV = DATASET_DIR / "users.csv"
GROUPS_CSV = DATASET_DIR / "groups.csv"
GROUP_MEMBERS_CSV = DATASET_DIR / "group_members.csv"
BUSINESS_CSV = DATASET_DIR / "business_accounts.csv"
USER_BUSINESS_HISTORY_CSV = DATASET_DIR / "user_business_history.csv"
MESSAGE_HISTORY_CSV = DATASET_DIR / "message_history.csv"
MESSAGE_EVENTS_CSV = DATASET_DIR / "message_events.csv"
IMAGES_CSV = DATASET_DIR / "images.csv"
VOICE_NOTES_CSV = DATASET_DIR / "voice_notes.csv"
SUMMARY_CSV = DATASET_DIR / "daily_notification_summary.csv"