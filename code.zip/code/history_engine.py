from loader import load_all_data

data = load_all_data()

history = data["message_history"]
events = data["message_events"]


def get_history(user_id):

    user_history = history[
        history["user_id"] == user_id
    ]

    if len(user_history) == 0:
        return []

    return user_history.tail(5).to_dict("records")


def get_evidence_ids(user_id):

    user_history = history[
        history["user_id"] == user_id
    ]

    if len(user_history) == 0:
        return "none"

    ids = user_history.tail(3)["message_id"].tolist()

    return ";".join(ids)