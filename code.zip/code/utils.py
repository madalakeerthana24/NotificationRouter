from pathlib import Path
from config import LOG_DIR, LOG_FILE

LOG_DIR.mkdir(parents=True, exist_ok=True)

def write_log(message):
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(message + "\n")

def ensure_output_folder():
    from config import OUTPUT_DIR
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)