from loader import load_all_data

data = load_all_data()

users = data["users"]
summary = data["summary"]


def get_user_profile(user_id):

    row = users[
        users["user_id"] == user_id
    ]

    if len(row) == 0:
        return {}

    return row.iloc[0].to_dict()


def get_notification_load(user_id):

    row = summary[
        summary["user_id"] == user_id
    ]

    if len(row) == 0:
        return 0

    return row.iloc[0].to_dict()