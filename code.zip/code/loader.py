import pandas as pd
from config import *

def load_csv(path):
    return pd.read_csv(path)

def load_all_data():
    return {
        "messages": load_csv(MESSAGES_CSV),
        "users": load_csv(USERS_CSV),
        "groups": load_csv(GROUPS_CSV),
        "group_members": load_csv(GROUP_MEMBERS_CSV),
        "business": load_csv(BUSINESS_CSV),
        "user_business_history": load_csv(USER_BUSINESS_HISTORY_CSV),
        "message_history": load_csv(MESSAGE_HISTORY_CSV),
        "message_events": load_csv(MESSAGE_EVENTS_CSV),
        "images": load_csv(IMAGES_CSV),
        "voice_notes": load_csv(VOICE_NOTES_CSV),
        "summary": load_csv(SUMMARY_CSV),
    }