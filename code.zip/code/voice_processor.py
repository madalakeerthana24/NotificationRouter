from loader import load_all_data

data = load_all_data()
voice = data["voice_notes"]

def process_voice(media_id):
    row = voice[voice["voice_id"] == media_id]

    if len(row) == 0:
        return ""

    # Return the file path for now.
    # You can later replace this with speech-to-text.
    return row.iloc[0]["file_path"]